#!/bin/bash
export CHROME_BIN=/usr/bin/chromium
if [ ! -d "/home/coder/project/workspace/angularapp" ]
then
    cp -r /home/coder/project/workspace/karma/angularapp /home/coder/project/workspace/;
fi

if [ -d "/home/coder/project/workspace/angularapp" ]
then
    echo "project folder present"
    cp /home/coder/project/workspace/karma/karma.conf.js /home/coder/project/workspace/angularapp/karma.conf.js;
    # checking for book-form.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/book-form" ]
    then
        cp /home/coder/project/workspace/karma/book-form.component.spec.ts /home/coder/project/workspace/angularapp/src/app/book-form/book-form.component.spec.ts;
    else
        echo "should create BookFormComponent FAILED";
        echo "BookFormComponent_should have a form for adding a book FAILED";
        echo "BookFormComponent_should have form controls for book details, author, category, publication year, publisher, price, and number of pages FAILED";
        echo "BookFormComponent_should have a button for adding a book FAILED";
        echo "BookFormComponent_should have addBook method FAILED";
    fi

    # checking for book-list.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/book-list" ]
    then
        cp /home/coder/project/workspace/karma/book-list.component.spec.ts /home/coder/project/workspace/angularapp/src/app/book-list/book-list.component.spec.ts;
    else
        echo "should create book-listComponent FAILED";
        echo "book-listComponent_should call loadBooks on ngOnInit FAILED";
    fi

    # checking for book.model.spec.ts component
    if [ -e "/home/coder/project/workspace/angularapp/src/app/models" ]
    then
        cp /home/coder/project/workspace/karma/book.model.spec.ts /home/coder/project/workspace/angularapp/src/app/models/book.model.spec.ts;
    else
        echo "BookModel_should create an instance FAILED";
        # echo "BookModel should have default property values FAILED";
        echo "BookModel_should update property values using setters FAILED";
    fi

    # checking for app.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app" ]
    then
        cp /home/coder/project/workspace/karma/app.component.spec.ts /home/coder/project/workspace/angularapp/src/app/app.component.spec.ts;
    else
        echo "AppComponent_should_render_app-book-form FAILED";
        echo "AppComponent_should_render_app-book-list FAILED";
    fi

    # checking for header.component.spec.ts component
    if [ -e "/home/coder/project/workspace/angularapp/src/app/header" ]
    then
        cp /home/coder/project/workspace/karma/header.component.spec.ts /home/coder/project/workspace/angularapp/src/app/header/header.component.spec.ts;
    else
        echo "should create HeaderComponent FAILED";
        echo "HeaderComponent_should navigate to Add New Book FAILED";
        echo "HeaderComponent_should navigate to View Books FAILED";
        echo "HeaderComponent_should have Bookstore as the brand FAILED";
        echo "HeaderComponent_should have a link with text View Books FAILED";
    fi

    # checking for book.service.spec.ts component
    if [ -e "/home/coder/project/workspace/angularapp/src/app/services" ]
    then
        cp /home/coder/project/workspace/karma/book.service.spec.ts /home/coder/project/workspace/angularapp/src/app/services/book.service.spec.ts;
    else
        
        echo "BookService_should be created FAILED";
        echo "BookService_should have getBooks method FAILED";
        echo "BookService_should have getBook method FAILED";
        echo "BookService_should have addBook method FAILED";
        echo "BookService_should add a book and return it FAILED";
        echo "BookService_should get books FAILED";
    fi

    if [ -d "/home/coder/project/workspace/angularapp/node_modules" ];
    then
        cd /home/coder/project/workspace/angularapp/
        npm test;
    else
        cd /home/coder/project/workspace/angularapp/
        yes | npm install
        npm test
    fi 
else   
        echo "should create BookFormComponent FAILED";
        echo "BookFormComponent_should have a form for adding a book FAILED";
        echo "BookFormComponent_should have form controls for book details, author, category, publication year, publisher, price, and number of pages FAILED";
        echo "BookFormComponent_should have a button for adding a book FAILED";
        echo "BookFormComponent_should have addBook method FAILED";
        echo "should create book-listComponent FAILED";
        echo "book-listComponent_should call loadBooks on ngOnInit FAILED";
        echo "BookModel_should create an instance FAILED";
        # echo "BookModel should have default property values FAILED";
        echo "BookModel_should update property values using setters FAILED";
        echo "AppComponent_should_render_app-book-form FAILED";
        echo "AppComponent_should_render_app-book-list FAILED";
        echo "should create HeaderComponent FAILED";
        echo "HeaderComponent_should navigate to Add New Book FAILED";
        echo "HeaderComponent_should navigate to View Books FAILED";
        echo "HeaderComponent_should have Bookstore as the brand FAILED";
        echo "HeaderComponent_should have a link with text View Books FAILED";
        echo "BookService_should be created FAILED";
        echo "BookService_should have getBooks method FAILED";
        echo "BookService_should have getBook method FAILED";
        echo "BookService_should have addBook method FAILED";
        echo "BookService_should add a book and return it FAILED";
        echo "BookService_should get books FAILED";
fi
