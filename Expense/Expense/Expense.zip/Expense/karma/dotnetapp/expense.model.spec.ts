import { ExpenseModel } from './expense.model';

describe('ExpenseModel', () => {
    //fit('ExpenseModel_should_create_instance', () => {
    //    const expense = new ExpenseModel();
    //    expect(expense).toBeDefined();
    //    expect(expense instanceof ExpenseModel).toBeTruthy();
    //});


    //fit('ExpenseModel_should_have_default_property_values', () => {
    //    const expense = new ExpenseModel();
    //    expect(expense['id']).toBeUndefined();
    //    expect(expense['expenseDetails']).toBeUndefined();
    //    expect(expense['category']).toBeUndefined();
    //    expect(expense['amount']).toBeUndefined();
    //    expect(expense['paymentMode']).toBeUndefined();
    //    expect(expense['expenseDate']).toBeUndefined();
    //});

    fit('ExpenseModel_should_update_property_values_using_setters', () => {
        const expense = new ExpenseModel();

        expense['id'] = 1;
        expense['expenseDetails'] = 'New Expense Details';
        expense['category'] = 'New Category';
        expense['amount'] = 100.50;
        expense['paymentMode'] = 'Credit Card';
        expense['expenseDate'] = '2023-01-01';


        expect(expense['id']).toEqual(1);
        expect(expense['expenseDetails']).toEqual('New Expense Details');
        expect(expense['category']).toEqual('New Category');
        expect(expense['amount']).toEqual(100.50);
        expect(expense['paymentMode']).toEqual('Credit Card');
        expect(expense['expenseDate']).toEqual('2023-01-01');
    });
});