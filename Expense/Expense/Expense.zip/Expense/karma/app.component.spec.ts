import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { AppComponent } from './app.component';


// describe('AppComponent', () => {
//   let component: AppComponent;
//   let fixture: ComponentFixture<AppComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       imports: [RouterTestingModule],
//       declarations: [AppComponent, DashboardComponent]
//     }).compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AppComponent);
//     component = fixture.componentInstance;
//   });


//   it('should_render_router-outlet_InAppComponent', () => {
//     const compiled = fixture.nativeElement;
//     expect(compiled.querySelector('router-outlet')).toBeTruthy();
//   });
  
//   it('should_render_app-dashboard_InAppComponent', () => {
//     const compiled = fixture.nativeElement;
//     expect(compiled.querySelector('app-dashboard')).toBeTruthy();
//   });
  
// });


describe('AppComponent', () => {
  let fixture: ComponentFixture<AppComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(AppComponent);

  });

  fit('AppComponent_should_render_router-outlet', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('router-outlet')).toBeTruthy();
  });
  
  fit('AppComponent_should_render_app-dashboard', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('app-dashboard')).toBeTruthy();
  });

});
