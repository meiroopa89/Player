#!/bin/bash
export CHROME_BIN=/usr/bin/chromium
if [ ! -d "/home/coder/project/workspace/angularapp" ]
then
    cp -r /home/coder/project/workspace/karma/angularapp /home/coder/project/workspace/;
fi

if [ -d "/home/coder/project/workspace/angularapp" ]
then
    echo "project folder present"
    cp /home/coder/project/workspace/karma/karma.conf.js /home/coder/project/workspace/angularapp/karma.conf.js;
    # checking for header.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/header" ]
    then
        cp /home/coder/project/workspace/karma/header.component.spec.ts /home/coder/project/workspace/angularapp/src/app/header/header.component.spec.ts;
    else
        echo "should create HeaderComponent FAILED";
        echo "HeaderComponent_should navigate to Add New Expense FAILED";
        echo "HeaderComponent_should have ExpenseManager as the brand FAILED";
        echo "HeaderComponent_should have a link with text View Expenses FAILED";
    fi

    # checking for expense.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/expense" ]
    then
        cp /home/coder/project/workspace/karma/expense.component.spec.ts /home/coder/project/workspace/angularapp/src/app/expense/expense.component.spec.ts;
    else
        echo "should create ExpenseComponent FAILED";
        echo "ExpenseComponent_should have a form for adding expense FAILED";
        echo "ExpenseComponent_should have form controls for expense details, category, amount, payment mode, and expense date FAILED";
        echo "ExpenseComponent_should have a button for adding expense FAILED";
        echo "ExpenseComponent_should have addExpense method FAILED";
        # echo "should handle error when adding an expense fails FAILED";

    fi

    # checking for dashboard.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/dashboard" ]
    then
        cp /home/coder/project/workspace/karma/dashboard.component.spec.ts /home/coder/project/workspace/angularapp/src/app/dashboard/dashboard.component.spec.ts;
    else
        echo "should create DashboardComponent FAILED";
        echo "DashboardComponent_should call loadExpenses on ngOnInit FAILED";
        echo "DashboardComponent_should display table headers FAILED";

    fi

    # checking for app.component.spec.ts component

    if [ -d "/home/coder/project/workspace/angularapp/src/app" ]; then
        cp /home/coder/project/workspace/karma/app.component.spec.ts /home/coder/project/workspace/angularapp/src/app/app.component.spec.ts;
    else
        echo "AppComponent_should_render_router-outlet FAILED";
        echo "AppComponent_should_render_app-dashboard FAILED";
    fi

    # checking for expense.service.spec.ts component
    if [ -e "/home/coder/project/workspace/angularapp/src/app/services" ]
    #if [ -e "/home/coder/project/workspace/angularapp/src/app/expense.service.ts" ]
    then
        cp /home/coder/project/workspace/karma/expense.service.spec.ts /home/coder/project/workspace/angularapp/src/app/services/expense.service.spec.ts;
       # cp /home/coder/project/workspace/karma/expense.service.spec.ts /home/coder/project/workspace/angularapp/src/app/expense.service.spec.ts;
    else
        echo "ExpenseService_should_have_getExpenses_method FAILED";
        echo "ExpenseService_should_have_expenseservice FAILED";
        echo "ExpenseService_should_have_addExpense_method FAILED";
        echo "ExpenseService_should add an expense and return it FAILED";
        echo "ExpenseService_should_get_expenses FAILED";
    fi

     # checking for expense.model.spec.ts component
    if [ -e "/home/coder/project/workspace/angularapp/src/app/models" ]
    #if [ -e "/home/coder/project/workspace/angularapp/src/app/expense.model.ts" ]
    then
        cp /home/coder/project/workspace/karma/expense.model.spec.ts /home/coder/project/workspace/angularapp/src/app/model/expense.model.spec.ts;
       # cp /home/coder/project/workspace/karma/expense.service.spec.ts /home/coder/project/workspace/angularapp/src/app/expense.service.spec.ts;
    else
        echo "ExpenseModel_should_update_property_values_using_setters FAILED";
    fi

    if [ -d "/home/coder/project/workspace/angularapp/node_modules" ]; 
    then
        cd /home/coder/project/workspace/angularapp/
        npm test;
    else
        cd /home/coder/project/workspace/angularapp/
        yes | npm install
        npm test
    fi 
else   
        echo "should create HeaderComponent FAILED";
        echo "HeaderComponent_should navigate to Add New Expense FAILED";
        echo "HeaderComponent_should have ExpenseManager as the brand FAILED";
        echo "HeaderComponent_should have a link with text View Expenses FAILED";
        echo "should create ExpenseComponent FAILED";
        echo "ExpenseComponent_should have a form for adding expense FAILED";
        echo "ExpenseComponent_should have form controls for expense details, category, amount, payment mode, and expense date FAILED";
        echo "ExpenseComponent_should have a button for adding expense FAILED";
        echo "ExpenseComponent_should have addExpense method FAILED";
        # echo "should handle error when adding an expense fails FAILED";
        echo "should create DashboardComponent FAILED";
        echo "DashboardComponent_should call loadExpenses on ngOnInit FAILED";
        echo "DashboardComponent_should display table headers FAILED";
        echo "AppComponent_should_render_router-outlet FAILED";
        echo "AppComponent_should_render_app-dashboard FAILED";
        echo "ExpenseService_should_have_expenseservice FAILED";
        echo "ExpenseService_should_have_getExpenses_method FAILED";
        echo "ExpenseService_should_have_addExpense_method FAILED";
        echo "ExpenseService_should add an expense and return it FAILED";
        echo "ExpenseService_should_get_expenses FAILED";
        echo "ExpenseModel_should_update_property_values_using_setters FAILED";

fi
